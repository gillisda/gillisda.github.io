import { Routes, RouterModule } from '@angular/router';

import { CustomerComponent }   from './customer.component';
import { CustomerDetailsComponent } from './customer-details.component';
import { CustomerEditComponent } from './customer-edit.component';
import { CustomerAddComponent } from './customer-add.component';
import { CanDeactivateGuard } from './can-deactivate.guard';
import { IRouting } from '../shared/interfaces';

const routes: Routes = [
  { 
    path: '', 
    component: CustomerComponent,
    children: [
      { path:'details', component: CustomerDetailsComponent },
      { path:'edit', component: CustomerEditComponent, canDeactivate: [ CanDeactivateGuard ] },
      { path:'add', component: CustomerAddComponent, canDeactivate: [ CanDeactivateGuard ] }
    ]
  }
];

export const customerRouting: IRouting = {
  routes: RouterModule.forChild(routes),
  components: [ CustomerComponent, CustomerDetailsComponent, CustomerEditComponent, CustomerAddComponent]
};

