import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { NgForm } from '@angular/forms';

import { DataService } from '../core/services/data.service';
import { DialogService } from '../core/services/dialog.service';
import { ICustomer } from '../shared/interfaces';

@Component({
  moduleId: module.id,
  selector: 'customer-add',
  templateUrl: 'customer-add.component.html'
})
export class CustomerAddComponent implements OnInit {

  customer: ICustomer = 
  {
    id: 0,
    name: '',
    review: '',
    rating: null
  };
  errorMessage: string;
  @ViewChild('customerForm') customerForm: NgForm;
  
  constructor(private router: Router, 
              private route: ActivatedRoute, 
              private dataService: DataService,
              public dialogService: DialogService) { }

  ngOnInit() {
      //Subscribe to params so if it changes we pick it up. Don't technically need that here
      //since param won't be changing while component is alive. 
      //Could use this.route.parent.snapshot.params["id"] to simplify it.
      this.route.parent.params.subscribe((params: Params) => {
        let id = +params['id'];
        this.dataService.getCustomer(id).subscribe((customer: ICustomer) => {
          //Quick and dirty clone used in case user cancels out of form
          const cust = JSON.stringify(customer);
          this.customer = JSON.parse(cust);
        });
      });

  }

  
  onSubmit() {
      this.dataService.addCustomer(this.customer)
        .subscribe((status: boolean) => {
          if (status) {
            this.customerForm.form.markAsPristine();
            this.router.navigate(['/']);
          }
          else {
            this.errorMessage = 'Unable to save customer';
          }
      });
  }
  
  onCancel(event: Event) {
    event.preventDefault();
    this.router.navigate(['/']);

  }

  canDeactivate(): Promise<boolean> | boolean {
    if (!this.customerForm.dirty) {
      return true;
    }
    return this.dialogService.confirm('Discard your changes?');
  }

}