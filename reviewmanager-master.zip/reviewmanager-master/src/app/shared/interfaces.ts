import { ModuleWithProviders } from '@angular/core';

export interface ICustomer {
    id: number;
    review: string;
    name: string;
    rating: number;
}

export interface IRouting {
    routes: ModuleWithProviders,
    components: any[]
}