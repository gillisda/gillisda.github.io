import { Component, Input, Output, EventEmitter, OnInit, ChangeDetectionStrategy } from '@angular/core';

import { Sorter } from '../core/services/sorter';

@Component({ 
  moduleId: module.id,
  selector: 'customers-grid', 
  templateUrl: 'customers-grid.component.html'
  //When using OnPush detectors, then the framework will check an OnPush 
  //component when any of its input properties changes, when it fires 
  //an event, or when an observable fires an event ~ Victor Savkin (Angular Team)
  //,changeDetection: ChangeDetectionStrategy.OnPush 
})
export class CustomersGridComponent implements OnInit {

  @Input() customers: any[] = [];
  @Output() sortRequest = new EventEmitter(); 
  constructor() { }
   
  ngOnInit() {

  }

  sort(prop: string) {
      this.sortRequest.emit(prop);
  }

}
