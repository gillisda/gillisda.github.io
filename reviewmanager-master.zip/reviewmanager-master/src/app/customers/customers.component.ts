import { Component, OnInit } from '@angular/core';
//import { Observable } from 'rxjs/Observable';

import { DataService } from '../core/services/data.service';
import { PagerService } from '../core/services/pager.service';
import { ICustomer } from '../shared/interfaces';
import { propertyResolver } from '../shared/property-resolver';

@Component({
  moduleId: module.id,
  selector: 'customers',
  templateUrl: 'customers.component.html'
})
export class CustomersComponent implements OnInit {

  title: string;
  filterText: string;
  itemsPerPage: number = 5;
  customers: ICustomer[] = [];
  pageCustomers: ICustomer[] = [];
  pages: Array<number> = [];
  currentPage: number = 0;
  currentSort: string;

  constructor(private dataService: DataService) { }

  ngOnInit() {
    this.title = 'Reviews';
    this.dataService.getCustomers()
      .subscribe((customers: ICustomer[]) => {
        this.customers = customers;
        console.log(this.customers.length)
        let nPages: number = Math.ceil(this.customers.length / this.itemsPerPage);
        this.pages = Array.from(Array(nPages), (x:any,i:any)=>i);
        this.page(0);
      });
  }
  page(page: number = 0) {
    if(this.pages.indexOf(page) >= 0) {
      this.currentPage = page;
      this.pageCustomers = this.customers.slice((this.itemsPerPage * page), (this.itemsPerPage * page) + this.itemsPerPage);
    }
  }
  sort(prop: string) {
    switch(prop) {
      case this.currentSort:
        this.customers.reverse();
        break;
      case 'rating':
        this.customers.sort((a, b) => {
          return b.rating - a.rating;
        });
        break;
      default:
        this.customers.sort((a, b) => {
          return a[prop].toLowerCase().localeCompare(b[prop].toLowerCase());
        });
    }
    this.currentSort = prop;
    this.page(0);
  }
}
