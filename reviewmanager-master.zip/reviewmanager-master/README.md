# dg Review Manager

A simple demonstration of an Angular app - Review Manager

Simply clone the project or download and extract the .zip and follow the instructions below to get started. Here are a few screenshots from the app:

<img width="500" src="src/images/screenshots/reviews-list.png" border="0" />

<br />

<img width="500" src="src/images/screenshots/review.png" border="0" />

<br />

<img width="500" src="src/images/screenshots/review-edit.png" border="0" />

## Demonstration Features 

* Dev open source tooling: VS Code, NodeJS, NPM, Express, Gulp, Protractor, Cucumber, et al
* Uses Angular2 and ES6 modules with the systemjs loader
* Implementation of an angular service for data persistence
* Restful persistence endpoint simulated in NoteJS Express
* Allows sorting of Reviews
* Allows pagination of Reviews
* BDD tests using Protractor and Cucumber

## Running the Application

1. Install `Node.js 6.x` or higher. The server uses ES2015 features so you need Node 6.x or higher!

1. Run `npm i` to install app dependencies

1. Run `npm start` in a separate terminal window to build the TypeScript, watch for changes and launch the web server

1. Go to http://localhost:3000 in your browser

Note: In order to run the tests, you are required to have the Java JDK installed
